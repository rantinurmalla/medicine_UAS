<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, typeization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];
$request = [];

if (isset($_SERVER['PATH_INFO'])) {
    $request = explode('/', trim($_SERVER['PATH_INFO'],'/'));
}

function getConnection() {
    $host = 'localhost';
    $db   = 'medicines_db';
    $user = 'root';
    $pass = ''; // Ganti dengan password MySQL Anda jika ada
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    try {
        return new PDO($dsn, $user, $pass, $options);
    } catch (\PDOException $e) {
        throw new \PDOException($e->getMessage(), (int)$e->getCode());
    }
}

function response($status, $data = NULL) {
    header("HTTP/1.1 " . $status);
    if ($data) {
        echo json_encode($data);
    }
    exit();
}

function validatemedicines($name, $type, $price, $stock) {
    $errors = [];
    if (empty($name)) {
        $errors[] = "Name is required";
    }
    if (empty($type)) {
        $errors[] = "Type is required";
    }
    if (empty($price)) {
        $errors[] = "Price is required";
    }
    if (!is_numeric($stock) || strlen($stock)) {
        $errors[] = "Stock must be a number";
    }
    return $errors;
}

$db = getConnection();

switch ($method) {
    case 'GET':
        if (!empty($request) && isset($request[0])) {
            $id = $request[0];
            $stmt = $db->prepare("SELECT * FROM medicines WHERE id = ?");
            $stmt->execute([$id]);
            $medicine = $stmt->fetch();
            if ($medicine) {
                response(200, $medicine);
            } else {
                response(404, ["message" => "medicine not found"]);
            }
        } else {
            $stmt = $db->query("SELECT * FROM medicines");
            $medicines = $stmt->fetchAll();
            response(200, $medicines);
        }
        break;
        // if (!empty($request) && isset($request[0])) {
        //     if ($request[0] === 'search') {
        //         // 5.1 Search functionality
        //         $searchTerm = $_GET['term'] ?? '';
        //         $stmt = $db->prepare("SELECT * FROM medicines WHERE name LIKE ? OR type LIKE ?");
        //         $searchTerm = "%$searchTerm%";
        //         $stmt->execute([$searchTerm, $searchTerm]);
        //         $medicines = $stmt->fetchAll();
        //         response(200, $medicines);
        //     } else {
        //         // Get specific medicines
        //         $id = $request[0];
        //         $stmt = $db->prepare("SELECT * FROM medicines WHERE id = ?");
        //         $stmt->execute([$id]);
        //         $medicines = $stmt->fetch();
        //         if ($medicines) {
        //             response(200, $medicines);
        //         } else {
        //             response(404, ["message" => "medicines not found"]);
        //         }
        //     }
        // } else {
        //     // 5.2 Pagination
        //     $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        //     $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
        //     $offset = ($page - 1) * $limit;

        //     $stmt = $db->prepare("SELECT * FROM medicines LIMIT ? OFFSET ?");
        //     $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        //     $stmt->bindValue(2, $offset, PDO::PARAM_INT);
        //     $stmt->execute();
        //     $medicines = $stmt->fetchAll();

        //     $totalStmt = $db->query("SELECT COUNT(*) FROM medicines");
        //     $total = $totalStmt->fetchColumn();

        //     response(200, [
        //         'medicines' => $medicines,
        //         'total' => $total,
        //         'page' => $page,
        //         'limit' => $limit
        //     ]);
        // }
        // break;
    
    case 'POST':
        $data = json_decode(file_get_contents("php://input"));
        if (!isset($data->name) || !isset($data->type) || !isset($data->price) || !isset($data->stock)) {
            response(400, ["message" => "Missing required fields"]);
        }
        // $errors = validatemedicines($data->name ?? '', $data->type ?? '', $data->price ?? '', $data->stock ?? '');
        // if (!empty($errors)) {
        //     response(404, ["errors" => $errors]);
        // }
        $sql = "INSERT INTO medicines (name, type, price, stock) VALUES (?, ?, ?, ?)";
        $stmt = $db->prepare($sql);
        if ($stmt->execute([$data->name, $data->type, $data->price, $data->stock])) {
            response(201, ["message" => "Medicine created", "id" => $db->lastInsertId()]);
        } else {
            response(500, ["message" => "Failed to create Medicine"]);
        }
        break;
    
    case 'PUT':
        if (empty($request) || !isset($request[0])) {
            response(404, ["message" => "Medicine ID is required"]);
        }
        $id = $request[0];
        $data = json_decode(file_get_contents("php://input"));
        if (!isset($data->name) || !isset($data->type) || !isset($data->price) || !isset($data->stock)) {
            response(400, ["message" => "Missing required fields"]);
        }
        // $errors = validatemedicines($data->name ?? '', $data->type ?? '', $data->price ?? '', $data->stock ?? '');
        // if (!empty($errors)) {
        //     response(404, ["errors" => $errors]);
        // }
        $sql = "UPDATE medicines SET name = ?, type = ?, price = ?, stock = ? WHERE id = ?";
        $stmt = $db->prepare($sql);
        if ($stmt->execute([$data->name, $data->type, $data->price, $data->stock, $id])) {
            response(200, ["message" => "Medicine updated"]);
        } else {
            response(500, ["message" => "Failed to update Medicine"]);
        }
        break;
    
    case 'DELETE':
        if (empty($request) || !isset($request[0])) {
            response(404, ["message" => "Medicine ID is required"]);
        }
        $id = $request[0];
        $sql = "DELETE FROM medicines WHERE id = ?";
        $stmt = $db->prepare($sql);
        if ($stmt->execute([$id])) {
            response(200, ["message" => "Medicine deleted"]);
        } else {
            response(500, ["message" => "Failed to delete Medicine"]);
        }
        break;
    
    default:
        response(405, ["message" => "Method not allowed"]);
        break;
}
?>